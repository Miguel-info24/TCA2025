package com.miguel.vannucci.controllers;

import io.javalin.http.Handler;

public class CarpinteiroDashboardController {
    public Handler get = ctx -> {
        ctx.render("carpinteiro_Dashboard.ftl");
    };
    public Handler atualizar = ctx -> {
        ctx.render("carpinteiro_Atualizar.ftl");
    };
}
